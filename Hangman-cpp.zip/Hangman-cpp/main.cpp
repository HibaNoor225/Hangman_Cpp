#include "HangmanUI.h"
#include <iostream>

int main() {
	HangmanUI hangman;
	hangman.run();
	return 0;
}
